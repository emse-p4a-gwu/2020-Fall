# Name:      Last, First
# GW Net ID: Insert your GWNetID here

# I worked with the following classmates on this assignment:
# 1) Name: Last, First
# 2) Name: Last, First

######################################################################
# Place your solutions here
######################################################################

integerSquareRoot <- function(x) {
    return(42)
}

fabricYards <- function(inches) {
    return(42)
}

fabricExcess <- function(inches) {
    return(42)
}

isPerfectCube <- function(x) {
    return(42)
}

kthDigit <- function(x, k) {
    return(42)
}

numberOfPoolBalls <- function(rows) {
    return(42)
}

#--------------------------------------------------------------
# ignore_rest: The autograder will ignore all code below here

# Turtle Graphics - no test functions for these, just run them and view the
# output to make sure it's producing the correct graphic

turtleSquare <- function(s) {
    return(42)
}

# Run to test the output
library(TurtleGraphics)
turtle_init()
turtle_do({
    turtleSquare(50)
})

# Bonus Credit (Optional):

turtleTriangle <- function(s) {
    return(42)
}
