
# Source your notes.py file
reticulate::source_python('notes.py')
