
library(reticulate)

# Source your notes.py file
reticulate::source_python('notes.py')

reticulate::repl_python()