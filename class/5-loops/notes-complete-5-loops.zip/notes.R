
for (i in 1:5) {
    if ((i %% 2) == 0) {
        cat('--')
    } else if ((i %% 3) == 0) {
        cat('----')
    }
    cat(i, '\n')
}

i = 1: 1
i = 2: --2
i = 3: ----3
i = 4: --4
i = 5: 5



n <- 6
for (i in seq(n)) {
    cat('|')
    for (j in seq(1, n, 2)) {
        cat('*')
    }
    cat('|', '\n')
}

i = 1, j = 1: |***|
i = 1, j = 3:
i = 1, j = 5:

i = 2, j = 1: |***|
i = 2, j = 3:
i = 2, j = 5:

i = 3, j = 1: |***|
i = 3, j = 3:
i = 3, j = 5:

# ------------------------------------------------
# Practice 1: for loops

# 1) sumFromMToN(m, n): Write a function that sums the total
#    of the integers between m and n. Challenge: Try solving this
#    without a loop!

sumFromMToN <- function(m, n) {
    return(sum(seq(m, n)))
}

sumFromMToN <- function(m, n) {
    total <- 0
    for (i in seq(m, n)) {
        total <- total + i
    }
    return(total)
}

sumToN <- function(n) {
    return(n*(n+1)/2)
}

sumFromMToN <- function(m, n) {
    return(sumToN(n) - sumToN(m-1))
}


sumFromMToN(5, 10) == (5 + 6 + 7 + 8 + 9 + 10)
sumFromMToN(1, 1) == 1

# 2) sumEveryKthFromMToN(m, n, k): Write a function to sum
#    every kth integer from m to n.

sumEveryKthFromMToN <- function(m, n, k) {
    total <- 0
    for (i in seq(m, n, by = k)) {
        total <- total + i
    }
    return(total)
}

sumEveryKthFromMToN(1, 10, 2) == (1 + 3 + 5 + 7 + 9)
sumEveryKthFromMToN(5, 20, 7) == (5 + 12 + 19)
sumEveryKthFromMToN(0, 0, 1) == 0

# 3) sumOfOddsFromMToN(m, n): Write a function that sums
#    every _odd_ integer between m and n.


sumOfOddsFromMToN <- function(m, n) {
    total <- 0
    for (i in seq(m, n)) {
        if ((i %% 2) == 1) {
            total <- total + i
        }
    }
    return(total)
}

sumOfOddsFromMToN(4, 10) == (5 + 7 + 9)
sumOfOddsFromMToN(5, 9) == (5 + 7 + 9)










for (i in 1:3) {
    cat('|')
    for (j in 1:5) {
        if (j == 3) {
            break
        }
        cat('*')
    }
    cat('|', '\n')
}


i = 1, j = 1: |**|
i = 1, j = 2:
i = 1, j = 3:
i = 1, j = 4:
i = 1, j = 5:


for (i in 1:3) {
    cat('|')
    for (j in 1:5) {
        if (j == 3) {
            next
        }
        cat('*')
    }
    cat('|', '\n')
}

i = 1, j = 1: |****|
i = 1, j = 2:
i = 1, j = 3:
i = 1, j = 4:
i = 1, j = 5:







# ------------------------------------------------
# Practice 2: break and next

# sumOfOddsFromMToNMax(m, n, max): Write a function that sums every odd
# integer from m to n until the sum is less than the value max.
# Your solution should use both break and next statements.

sumOfOddsFromMToNMax <- function(m, n, max) {
    total <- 0
    for (i in m:n) {
        if ((i %% 2) == 0) {
            next
        }
        total <- total + i
        if (total > max) {
            total <- total - i
            break
        }
    }
    return(total)
}


sumOfOddsFromMToNMax(1, 5, 4) == (1 + 3)
sumOfOddsFromMToNMax(1, 5, 3) == (1)
sumOfOddsFromMToNMax(1, 5, 10) == (1 + 3 + 5)









f <- function(x) {
    n <- 1
    while (n < x) {
        cat(n, '\n')
        n <- 2*n
    }
}

f(5)
f(10)
f(50)
f(60)
f(64)
f(65)




# ------------------------------------------------
# Practice 3: while loops

# 1) isMultipleOf4Or7(n): Write a function that returns TRUE
#    if n is a multiple of 4 or 7 and FALSE otherwise.

isMultipleOf4Or7 <- function(n) {
    if (n == 0) { return(FALSE) }
    return((n %% 4 == 0) | (n %% 7 == 0))
}

isMultipleOf4Or7(0) == FALSE
isMultipleOf4Or7(1) == FALSE
isMultipleOf4Or7(4) == TRUE
isMultipleOf4Or7(7) == TRUE
isMultipleOf4Or7(28) == TRUE

# 2) nthMultipleOf4Or7(n): Write a function that returns the
#    nth positive integer that is a multiple of either 4 or 7.

nthMultipleOf4Or7 <- function(n) {
    count <- 1
    guess <- 0
    while (count <= n) {
        guess <- guess + 1
        if (isMultipleOf4Or7(guess)) {
            count <- count + 1
        }
    }
    return(guess)
}

# 0  1  2  3  (4)  5  6  (7)  (8)  9  10

nthMultipleOf4Or7(1) == 4
nthMultipleOf4Or7(2) == 7
nthMultipleOf4Or7(3) == 8
nthMultipleOf4Or7(4) == 12
nthMultipleOf4Or7(5) == 14
nthMultipleOf4Or7(6) == 16






# ------------------------------------------------
# Practice 4: prime numbers

# 1) isPrime(n): Write a function that takes a non-negative
#    integer, n, and returns TRUE if it is a prime number and
#    FALSE otherwise. Here's some test cases:

isPrime <- function(n) {
    if (n == 2) { return(TRUE) }
    for (i in seq(2, n-1)) {
        if (n %% i == 0) {
            return(FALSE)
        }
    }
    return(TRUE)
}

isPrime(1) == FALSE
isPrime(2) == TRUE
isPrime(7) == TRUE
isPrime(13) == TRUE
isPrime(14) == FALSE

# 2) nthPrime(n): Write a function that takes a non-negative
#    integer, n, and returns the nth prime number, where nthPrime(1)
#    returns the first prime number (2). Hint: use the function
#    isPrime(n) as a helper function!

nthPrime <- function(n) {
    counter <- 1
    guess <- 0
    while (counter <= n) {
        guess <- guess + 1
        if (isPrime(guess)) {
            counter = counter + 1
        }
    }
    return(guess)
}

nthPrime(1) == 2
nthPrime(2) == 3
nthPrime(3) == 5
nthPrime(4) == 7
nthPrime(7) == 17

