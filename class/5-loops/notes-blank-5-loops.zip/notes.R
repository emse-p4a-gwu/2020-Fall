# ------------------------------------------------
# Practice 1: for loops

# 1) sumFromMToN(m, n): Write a function that sums the total
#    of the integers between m and n. Challenge: Try solving this
#    without a loop!

sumFromMToN(5, 10) == (5 + 6 + 7 + 8 + 9 + 10)
sumFromMToN(1, 1) == 1

# 2) sumEveryKthFromMToN(m, n, k): Write a function to sum
#    every kth integer from m to n.

sumEveryKthFromMToN(1, 10, 2) == (1 + 3 + 5 + 7 + 9)
sumEveryKthFromMToN(5, 20, 7) == (5 + 12 + 19)
sumEveryKthFromMToN(0, 0, 1) == 0

# 3) sumOfOddsFromMToN(m, n): Write a function that sums
#    every _odd_ integer between m and n.

sumOfOddsFromMToN(4, 10) == (5 + 7 + 9)
sumOfOddsFromMToN(5, 9) == (5 + 7 + 9)





# ------------------------------------------------
# Practice 2: break and next

# sumOfOddsFromMToNMax(m, n, max): Write a function that sums
#   every _odd_ integer from m to n up to and including some value max.
#   Your solution should use both break and next statements.

sumOfOddsFromMToNMax(1, 5, 4) == 4
sumOfOddsFromMToNMax(1, 5, 3) == 1
sumOfOddsFromMToNMax(1, 5, 10) == (1 + 3 + 5)





# ------------------------------------------------
# Practice 3: while loops

# 1) isMultipleOf4Or7(n): Write a function that returns TRUE
#    if n is a multiple of 4 or 7 and FALSE otherwise.

isMultipleOf4Or7(0) == FALSE
isMultipleOf4Or7(1) == FALSE
isMultipleOf4Or7(4) == TRUE
isMultipleOf4Or7(7) == TRUE
isMultipleOf4Or7(28) == TRUE

# 2) nthMultipleOf4Or7(n): Write a function that returns the
#    nth positive integer that is a multiple of either 4 or 7.

nthMultipleOf4Or7(1) == 4
nthMultipleOf4Or7(2) == 7
nthMultipleOf4Or7(3) == 8
nthMultipleOf4Or7(4) == 12
nthMultipleOf4Or7(5) == 14
nthMultipleOf4Or7(6) == 16






# ------------------------------------------------
# Practice 4: prime numbers

# 1) isPrime(n): Write a function that takes a non-negative
#    integer, n, and returns TRUE if it is a prime number and
#    FALSE otherwise. Here's some test cases:

isPrime(1) == FALSE
isPrime(2) == TRUE
isPrime(7) == TRUE
isPrime(13) == TRUE
isPrime(14) == FALSE

# 2) nthPrime(n): Write a function that takes a non-negative
#    integer, n, and returns the nth prime number, where nthPrime(1)
#    returns the first prime number (2). Hint: use the function
#    isPrime(n) as a helper function!

nthPrime(1) == 2
nthPrime(2) == 3
nthPrime(3) == 5
nthPrime(4) == 7
nthPrime(7) == 17

