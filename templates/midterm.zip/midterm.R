# Name:      Last, First
# GW Net ID: Insert your GWNetID here
# (this is the part of your email before "@gwu.edu")

#############################################################
# HONOR CODE
#
# By typing an "x" in each of the brackets below (e.g. [x]),
# I promise that on this exam...
#
# [] I will not **offer** help to other classmates.
# [] I will not **accept** help from other classmates.
#############################################################


# Defining almostEqual here in case you need to use it
almostEqual <- function(n1, n2, threshold = 0.00001) {
    return(abs(n1 - n2) <= threshold)
}


# Type your responses to each question below

# TRUE or FALSE

# --- 1)

# --- 2)

# --- 3)

# --- 4)

# --- 5)


# Short Answer

# --- 6)

# --- 7)

# --- 8)

# --- 9)


# Mystery Functions

# --- 10)

# --- 11)


# Debugging

# --- 12)

# --- 13)

# --- 14)


# Write Functions

# --- 15)


# Bonus


