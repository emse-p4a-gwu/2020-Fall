# Practice 1

area_sf <- 46.87 # These are in sq miles
area_chicago <- 227.63
area_dc <- 61.05

pop_sf <- 884363
pop_chicago <- 2716450
pop_dc <- 693972

dens_chicago <- pop_chicago / area_chicago
dens_sf <- pop_sf / area_sf
dens_dc <- pop_dc / area_dc

(dens_sf*area_dc) - pop_dc


# Practice 2

w <- TRUE
x <- FALSE
y <- TRUE

# Fill in relational operators to make the 
# following statement return TRUE:

# ! (w __ x) & ! (y __ x)

# This is the same saying each of these must be TRUE:
# ! (w __ x)  
# ! (y __ x)

# Which is the same saying each of these must be FALSE:
# (w __ x)  
# (y __ x)

# Now just replace the objects with their values:
# (TRUE __ FALSE)  
# (TRUE __ FALSE)

# To make these FALSE, I should use the == symbol in each

! (w == x) & ! (y == x)
