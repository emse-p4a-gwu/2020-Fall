# ------------------------------------------------
# Quick code tracing 1

rep(c(TRUE, FALSE, "TRUE"), 2)

seq(FALSE, 3)

rep(c(seq(3), seq(2)), each = 2)





# ------------------------------------------------
# Quick code tracing 2

f <- function(x) {
    m <- x
    n <- sum(x + 4)
    m <- m + 5
    return(c(m, n))
}

# What will this return?

x <- c(1, 3)
f(x)


y <- c(TRUE, FALSE, 1)
f(y)






# ------------------------------------------------
# Think-Pair-Share 1

# Re-write isPrime(n) from last week, but **without loops!**.
# Remember, isPrime(n) takes a non-negative integer, n, and
# returns TRUE if it is a prime number and FALSE otherwise.
# Here's some test cases:

# Loop solution
isPrime <- function(n) {
    if (n <= 1) {
        return(FALSE)
    }
    if (n == 2) {
        return(TRUE)
    }
    for (i in seq(2, n-1)) {
        if ((n %% i) == 0) {
            return(FALSE)
        }
    }
    return(TRUE)
}

# Vector solution 1
isPrime <- function(n) {
    if (n <= 1) {
        return(FALSE)
    }
    if (n == 2) {
        return(TRUE)
    }
    test <- (n %% (seq(2, n-1))) == 0
    if (any(test)) {
        return(FALSE)
    }
    return(TRUE)
}

# Vector solution 2
isPrime <- function(n) {
    if (n <= 1) {
        return(FALSE)
    }
    if (n == 2) {
        return(TRUE)
    }
    x <- seq(2, n-1) # Checking each number from 2 to n-1
    y <- n %% x # Compute remainders
    if (any(y == 0)) {
        return(FALSE)
    }
    return(TRUE)
}


isPrime(1) == FALSE
isPrime(2) == TRUE
isPrime(7) == TRUE
isPrime(13) == TRUE
isPrime(14) == FALSE





# ------------------------------------------------
# Quick code tracing 3

f <- function(x) {
    for (i in seq(length(x))) {
        x[i] <- x[i] + sum(x) + max(x)
    }
    return(x)
}

# What will this return?

x <- c(1, 2, 3)
f(x)

# Main: x <- c(10, 27, 70)

c(10, 27, 70)




# ------------------------------------------------
# Think-Pair-Share 2

# 1) reverse(x): Write a function that returns the vector
# in reverse order. You cannot use the rev() function.

reverseVector <- function(x) {
    y <- x
    for(i in 1:length(x)) {
        y[i] <- x[length(x) - i + 1]
    }
    return(y)
}

reverseVector <- function(x) {
    indices <- seq(length(x), 1, by = -1)
    return(x[indices])
}

all(reverseVector(c(5, 1, 3)) == c(3, 1, 5))
all(reverseVector(c('a', 'b', 'c')) == c('c', 'b', 'a'))
all(reverseVector(c(FALSE, TRUE, TRUE)) == c(TRUE, TRUE, FALSE))




# 2) alternatingSum(a): Write a function that takes a vector
# of numbers a and returns the alternating sum, where the
# sign alternates from positive to negative or vice versa.

alternatingSum <- function(a) {
    total <- 0
    for (i in 1:length(a)) {
        if ((i %% 2) == 1) {
            total <- total + a[i]
        } else {
            total <- total - a[i]
        }
    }
    return(total)
}


alternatingSum <- function(a) {
    ones <- rep(c(1, -1), length(a))
    ones <- ones[1:length(a)]
    return(sum(ones*a))
}

alternatingSum(c(5,3,8,4)) == (5 - 3 + 8 - 4)
alternatingSum(c(1,2,3)) == (1 - 2 + 3)
alternatingSum(c(0,0,0)) == 0
alternatingSum(c(-7,5,3)) == (-7 - 5 + 3)

